<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Search up a Director</title>
    <link rel= "stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>

<body>
    <?php
    session_start();
    if(!isset($_SESSION['username'])){
        header("location: index.php");
    }
    if($_SESSION['username'] != 'admin'){
        header("location: home.php");
    }
    ?>
    <h1 class="w3-blue w3-margin w3-center w3-container w3-jumbo">Search up a Director</h1><br>
    <h1 class="w3-center w3-container"><u>Enter director to search</u></h1>
    <form action="adminSearchDirector.php" method="POST" class="w3-center w3-large">
        <label for="dir">Director:</label>
        <input type="text" id="dir" name="director">
        <br>
        <input type="submit" value="search" class="w3-ripple w3-hover-blue">
    </form>
    <br>

    <p class="w3-center w3-large"><a href="admin.php">back to admin tools</a></p>

    <?php
    
    if($_SERVER["REQUEST_METHOD"]=="POST"){
        $director=$_POST['director'];
    
        $dsn='mysql:host=localhost;dbname=project';
    $username='root';
    $password='root';
    
    try{
        $pdo=new PDO($dsn, $username, $password);
    }catch(PDOException $e){
        die('Connection Error'.$e->getMessage());
    }
    $sql="SELECT * FROM director WHERE director_name='$director'";
    $statement=$pdo->prepare($sql);               
    $statement->execute();
    echo "<div class=w3-table>";
    echo "<table>";
    echo "<thead>";
    echo "<tr> <th>directorID</th> <th>director</th> </tr>";
    echo "</thead>";
foreach ($statement as $row){
    echo "<tr>";
    echo "<td>".$row['director_id']. "</td>";
    echo "<td>".$row['director_name']."</td>";
    echo "</tr>";
}
echo "</table>";
echo "</div>";
}
    $pdo=null;
    ?>
</body>
</html>
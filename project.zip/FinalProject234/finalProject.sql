-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 28, 2023 at 02:45 AM
-- Server version: 5.7.24
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `director`
--

CREATE TABLE `director` (
  `director_id` int(11) NOT NULL,
  `director_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `director`
--

INSERT INTO `director` (`director_id`, `director_name`) VALUES
(1, 'Shawn Levy'),
(2, 'Quentin Tarantino'),
(3, 'Christopher Nolan'),
(4, 'Ridley Scott'),
(5, 'Peter Jackson'),
(8, 'Spike Lee');

-- --------------------------------------------------------

--
-- Table structure for table `movie`
--

CREATE TABLE `movie` (
  `movie_id` int(11) NOT NULL,
  `movie_name` varchar(255) NOT NULL,
  `director_id` int(11) NOT NULL,
  `rating` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `movie`
--

INSERT INTO `movie` (`movie_id`, `movie_name`, `director_id`, `rating`) VALUES
(1, 'Real Steel', 1, 10),
(2, 'Kill Bill', 2, 9),
(3, 'Kill Bill pt.2', 2, 7),
(4, 'Once Upon a Time in Hollywood', 2, 10),
(5, 'The Dark Knight', 3, 8),
(6, 'Inception', 3, 10),
(7, 'Tenet', 3, 6),
(8, 'Napoleon', 4, 5),
(9, 'Alien', 4, 8),
(10, 'The Fellowship of the Ring', 5, 10),
(12, 'The Two Towers', 5, 9);

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `username`, `password`) VALUES
(6, 'Jacob', '$2y$10$t3mNMICKzwQrYHVXgKQhXu5vbluQehGx.PuzSqTaRs5hEYHkQ8kjC'),
(7, 'admin', '$2y$10$RmpEc7NSLTfluuCzVeB9ruaB48kwxxLkOerE.2kCtrDtY314bdSlK'),
(10, 'NewUserUpdated', '$2y$10$DRIjmLY5IoWxLr2Efpyi9eO9x/SogmaQeBIZG6zFv8z.Z3tODegrW'),
(11, 'JacobL', '$2y$10$wx5rglspiJXsoudS7.9M.OuELFRU5XGZBb4TpN24mN.ZAgNOBnUT.'),
(12, 'Jake', '$2y$10$rUep0RyhvbJqfGEPeSwtV.91IrpRtYfRjjW/N7HmFqiToO5uWsmc2'),
(13, 'Jakee', '$2y$10$gYqahj2suS5FdukOSpaSYeKqo9HBwn8wnTfs5cLZ6LMSIvtsOh8x6');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `director`
--
ALTER TABLE `director`
  ADD PRIMARY KEY (`director_id`);

--
-- Indexes for table `movie`
--
ALTER TABLE `movie`
  ADD PRIMARY KEY (`movie_id`),
  ADD KEY `director_id` (`director_id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `director`
--
ALTER TABLE `director`
  MODIFY `director_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `movie`
--
ALTER TABLE `movie`
  MODIFY `movie_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `movie`
--
ALTER TABLE `movie`
  ADD CONSTRAINT `movie_ibfk_1` FOREIGN KEY (`director_id`) REFERENCES `director` (`director_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Add a User</title>
    <link rel= "stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>

<body>
    <?php
    session_start();
    if(!isset($_SESSION['username'])){
        header("location: index.php");
    }
    if($_SESSION['username'] != 'admin'){
        header("location: home.php");
    }
    ?>
    <h1 class="w3-blue w3-margin w3-center w3-container w3-jumbo">Add a User</h1><br>
    <h1 class="w3-center w3-container"><u>Create username and password</u></h1>
    <form action="adminAdd.php" method="POST" class="w3-center w3-large">
        <label for="user">Create a unique username:</label>
        <input type="text" id="user" name="username">
        <br>
        <label for="pass">Create a password (7-12 char, 1 capital min):</label>
        <input type="text" id="pass" name="password">
        <br>
        <br>
        <input type="submit" value="create" class="w3-ripple w3-hover-blue">
    </form>
    <br>

    <p class="w3-center w3-large"><a href="admin.php">back to admin tools</a></p>

    <?php
    $userStatus = "";
    $pwdEntered = "";
    $pwdHashed = "";
    
    if($_SERVER["REQUEST_METHOD"]=="POST"){
        $user=$_POST['username'];
        $pwdEntered=$_POST['password'];
    
        $dsn='mysql:host=localhost;dbname=project';
    $username='root';
    $password='root';
    
    try{
        $pdo=new PDO($dsn, $username, $password);
    }catch(PDOException $e){
        die('Connection Error'.$e->getMessage());
    }
    $sql="CREATE TABLE IF NOT EXISTS registration(
        id INT(11) NOT NULL AUTO_INCREMENT,
        username VARCHAR(255) NOT NULL,
        password VARCHAR(255) NOT NULL,
        PRIMARY KEY(id)
        )";
    
    $statement=$pdo->prepare($sql);   
    $statement->execute();
    }
    
        function check_user($username, $pwdEntered){
            global $pdo;
            $sql="SELECT username FROM registration WHERE username='$username'";
            $statement=$pdo->prepare($sql);
            $statement->execute();
            
            if($statement->rowCount() == 0){
                return check_password($pwdEntered);
            }
            else{
                echo "<h1>Username is already in use, please try again.</h1>";
                return false;
            }
        }
    
        function check_password($pwdEntered){
            if(strlen($pwdEntered) <= '12' && strlen($pwdEntered) >= '7'){
                if ($pwdEntered != strtolower($pwdEntered)){
                    return true;
                }
                else{
                    echo "<h1>Password does not contain a capital letter, please try again.</h1>";
                    return false;
                }
            }
            else{
                echo "<h1>Password is invalid length, please try again.</h1>";
                return false;
            }
        }
    
        if (isset($user) && $user != ""){
            $userStatus = check_user($user,$pwdEntered);
            if ($userStatus){
                $sql="INSERT INTO registration(username,password) VALUES(:username,:password)";
                $statement=$pdo->prepare($sql);
                
                $pwdHashed=password_hash($pwdEntered,PASSWORD_BCRYPT);
                
                $statement->bindParam(':username',$user);
                $statement->bindParam(':password',$pwdHashed);
                
                $statement->execute();
                echo "<h1>Succesfully registered</h1>";
            }
            else{
            }
        }
    
    
        $pdo=null;
    ?>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Classics Table</title>
    <link rel= "stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
    <h1 class="w3-yellow w3-margin w3-center w3-container w3-jumbo">My Ratings</h1>
    <div class="w3-bar w3-black">
    <a href="home.php" class="w3-bar-item w3-button">Home</a>
    <a href="favoriteMovie.php" class="w3-bar-item w3-button">My Favorite Movie</a>
    <a href="classics.php" class="w3-bar-item w3-button">Classic Movies</a>
    <a href="ratings.php" class="w3-bar-item w3-button">My Movie Ratings</a>
    </div>

    <?php
    session_start();
    if(!isset($_SESSION['username'])){
        header("location: index.php");
    }

    $dsn='mysql:host=localhost;dbname=project';
    $username='root';
    $password='root';

    try{
        $pdo=new PDO($dsn, $username, $password);
    }catch(PDOException $e){
        die('Connection Error'.$e->getMessage());
    }

    $sql="SELECT movie_name,rating FROM movie";
    $statement=$pdo->prepare($sql);
    $statement->execute();
    echo "<div class=w3-table>";
    echo "<table>";
    echo "<thead>";
    echo "<tr> <th>Movie Name</th> <th>Rating</th> </tr>";
    echo "</thead>";
    foreach ($statement as $row){
        echo "<tr>";
        echo "<td>".$row['movie_name']. "</td>";
        echo "<td>".$row['rating']."</td>";
        echo "</tr>";
    }
    echo "</table>";
    echo "</div>";
    $pdo=null;
    ?>



</body>
</html>
<!DOCTYPE html>
<html lang="en"> <!--admin username is admin and password is AdminPass-->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin functions</title>
    <link rel= "stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
    <h1 class="w3-grey w3-margin w3-center w3-jumbo">Admin Functions</h1>
    <div class="w3-bar w3-black">
    <a href="adminHome.php" class="w3-bar-item w3-button">Admin Home</a>
    <a href="admin.php" class="w3-bar-item w3-button">Admin Functions</a>
    </div>
    <?php

    session_start();
    if(!isset($_SESSION['username'])){
        header("location: index.php");
    }
    if($_SESSION['username'] != 'admin'){
        header("location: home.php");
    }

    ?>
    <br>
    <div class="w3-grey">
    <a href="adminAdd.php" class="w3-button">Add</a>
    <a href="adminDelete.php" class="w3-button">Delete</a>
    <a href="adminUpdate.php" class="w3-button">Update</a>
    <a href="adminSearch.php" class="w3-button">Search</a>
    </div>
    <?php

$dsn='mysql:host=localhost;dbname=project';
$username='root';
$password='root';

try{
    $pdo=new PDO($dsn, $username, $password);
}catch(PDOException $e){
    die('Connection Error'.$e->getMessage());
}

$sql="SELECT id, username, password FROM registration";
$statement=$pdo->prepare($sql);
$statement->execute();
echo "<div class=w3-table>";
echo "<table>";
echo "<thead>";
echo "<tr> <th>UserID </th> <th>Username </th> <th>Password</th> </tr>";
echo "</thead>";
foreach ($statement as $row){
    echo "<tr>";
    echo "<td>".$row['id']. "</td>";
    echo "<td>".$row['username']."</td>";
    echo "<td>".$row['password']."</td>";
    echo "</tr>";
}
echo "</table>";
echo "</div>";

?>
    <br>
    <div class="w3-grey">
    <a href="adminAddDirector.php" class="w3-button">Add</a>
    <a href="adminDeleteDirector.php" class="w3-button">Delete</a>
    <a href="adminUpdateDirector.php" class="w3-button">Update</a>
    <a href="adminSearchDirector.php" class="w3-button">Search</a>
    </div>
    </form>

    <?php
$sql="SELECT director_id, director_name FROM director";
$statement=$pdo->prepare($sql);
$statement->execute();
echo "<div class=w3-table>";
echo "<table>";
echo "<thead>";
echo "<tr> <th>DirectorID</th> <th>Director</th> </tr>";
echo "</thead>";
foreach ($statement as $row){
    echo "<tr>";
    echo "<td>".$row['director_id']. "</td>";
    echo "<td>".$row['director_name']."</td>";
    echo "</tr>";
}
echo "</table>";
echo "</div>";
?>

    <br>
    <div class="w3-grey">
    <a href="adminAddMovie.php" class="w3-button">Add</a>
    <a href="adminDeleteMovie.php" class="w3-button">Delete</a>
    <a href="adminUpdateMovie.php" class="w3-button">Update</a>
    <a href="adminSearchMovie.php" class="w3-button">Search</a>
    </div>
    </form>

    <?php
$sql="SELECT movie_id, movie_name, director_id, rating FROM movie";
$statement=$pdo->prepare($sql);
$statement->execute();
echo "<div class=w3-table>";
echo "<table>";
echo "<thead>";
echo "<tr> <th>MovieID</th> <th>Movie</th> <th>DirectorID</th> <th>Rating</th> </tr>";
echo "</thead>";
foreach ($statement as $row){
    echo "<tr>";
    echo "<td>".$row['movie_id']. "</td>";
    echo "<td>".$row['movie_name']."</td>";
    echo "<td>".$row['director_id']. "</td>";
    echo "<td>".$row['rating']."</td>";
    echo "</tr>";
}
echo "</table>";
echo "</div>";
$pdo=null;
?>
<!DOCTYPE html>
<html lang="en"> <!--admin username is admin and password is AdminPass-->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Home Page</title>
    <link rel= "stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
    <h1 class="w3-red w3-margin w3-center w3-jumbo">Admin Home Page</h1>
    <div class="w3-bar w3-black">
    <a href="adminHome.php" class="w3-bar-item w3-button">Admin Home</a>
    <a href="admin.php" class="w3-bar-item w3-button">Admin Functions</a>
    </div>
    <?php

    session_start();
    if(!isset($_SESSION['username'])){
        header("location: index.php");
    }
    if($_SESSION['username'] != 'admin'){
        header("location: home.php");
    }
    echo '<h1 class=w3-center>Welcome '.$_SESSION["username"].'!</h1>';

    ?>

    <div class="w3-center"><img src="Film Reel.png" alt="Film Reel"></div>

    

    <form action="logout.php" method="post" class="w3-center">
    <input type="submit" value="Logout">
    </form>
</body>
</html>
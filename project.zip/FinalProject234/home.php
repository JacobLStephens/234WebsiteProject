<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <link rel= "stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
    <h1 class="w3-red w3-margin w3-center w3-jumbo">Home Page</h1>
    <div class="w3-bar w3-black">
    <a href="home.php" class="w3-bar-item w3-button">Home</a>
    <a href="favoriteMovie.php" class="w3-bar-item w3-button">My Favorite Movie</a>
    <a href="classics.php" class="w3-bar-item w3-button">Classic Movies</a>
    <a href="ratings.php" class="w3-bar-item w3-button">My Movie Ratings</a>
    </div>
    <?php

    session_start();
    if(!isset($_SESSION['username'])){
        header("location: index.php");
    }
    echo '<h1 class=w3-center>Welcome '.$_SESSION["username"].'!</h1>';

    ?>

    <div class="w3-center"><img src="Film Reel.png" alt="Film Reel"></div>

    

    <form action="logout.php" method="post" class="w3-center">
    <input type="submit" value="Logout">
    </form>
</body>
</html>
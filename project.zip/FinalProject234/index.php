<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>LoginPage</title>
    <link rel= "stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>

<body>
    <?php
    $year = date('Y');
    ?>
    <h1 class="w3-light-green w3-margin w3-center w3-container w3-jumbo">Jacob's Movies</h1><br>
    <h1 class="w3-center w3-container"><u>Login</u></h1>
    <form action="index.php" method="POST" class="w3-center w3-large">
        <label for="user">Input username:</label>
        <input type="text" id="user" name="username">
        <br>
        <label for="pass">Input password:</label>
        <input type="password" id="pass" name="password">
        <br>
        <br>
        <input type="submit" value="Login" class="w3-ripple w3-hover-pale-green">
    </form>
    <br>

    <h1 class="w3-center w3-container"><u>Not already registered?</u></h1><br>
        <p class="w3-center w3-large"><a href="register.php">register here</a></p>
        

<?php

session_start();

$userStatus = "";
$pwdEntered = "";

if($_SERVER["REQUEST_METHOD"]=="POST"){
    $user=$_POST['username'];
    $pwdEntered=$_POST['password'];

    $_SESSION["username"]=$user;
    $_SESSION["password"]=$pwdEntered;

    $dsn='mysql:host=localhost;dbname=project';
    $username='root';
    $password='root';

    try{
        $pdo=new PDO($dsn, $username, $password);
    }catch(PDOException $e){
        die('Connection Error'.$e->getMessage());
    }  

function check_existing_user($username, $pwdEntered){
    global $pdo;
    $sql="SELECT username FROM registration WHERE username='$username'";
    $statement=$pdo->prepare($sql);
    $statement->execute();
    
    if($statement->rowCount() == 1){
        return check_matching_password($username, $pwdEntered);
    }
    else{
        echo "<h1 class='w3-text-red w3-center w3-container'>Username is incorrect, please try again.</h1>";
        return false;
    }
}

function check_matching_password($username, $pwdEntered){
    global $pdo;
    $sql="SELECT password FROM registration WHERE username=?";
    $statement=$pdo->prepare($sql);
    $statement->execute([$username]);

    $info=$statement->fetch();

    $hashedPassword=$info['password'];

    if(password_verify($pwdEntered,$hashedPassword)){
        return true;
    }
    else{
        echo "<h1 class='w3-text-red w3-center w3-container'>Password is incorrect, please try again.</h1>";
        return false;
    }
}

if (isset($user) && $user != ""){
    $userStatus = check_existing_user($user,$pwdEntered);
    if ($userStatus){
        if($user=="admin" && $pwdEntered=="AdminPass"){
            header("Location: adminHome.php");
        }
        else{
            header("Location: home.php");
        }
        
    }
    else{
        $_SESSION=array();
        session_destroy();
    }
}
else{
    echo "<h1 class='w3-text-red w3-center w3-container'>No username entered, please try again.</h1><br>";
    $_SESSION=array();
    session_destroy();
}
$pdo=null;
}   
else{
    $_SESSION=array();
    session_destroy();
}
?>
<footer class="w3-panel w3-center w3-text-gray w3-small">
    &copy; <?php echo $year; ?> Jacob Stephens

</body>
</html>
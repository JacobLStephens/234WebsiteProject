<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>You Agree!</title>
    <link rel= "stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
    <?php
    session_start();
    if(!isset($_SESSION['username'])){
        header("location: index.php");
    }
    ?>
    <h1 class="w3-purple w3-margin w3-center w3-container w3-jumbo">The Greatest Movie Ever</h1>
    <div class="w3-bar w3-black">
    <a href="home.php" class="w3-bar-item w3-button">Home</a>
    <a href="favoriteMovie.php" class="w3-bar-item w3-button">My Favorite Movie</a>
    <a href="classics.php" class="w3-bar-item w3-button">Classic Movies</a>
    <a href="ratings.php" class="w3-bar-item w3-button">My Movie Ratings</a>
    </div>

    <div class="w3-center"><img src="RealSteelPoster.png" alt="Real Steel Poster" class="w3-containter w3-padding"></div>
    
    <p class="w3-center"><u>Real Steel</u>-2011, directed by Shawn Levy</p>
    <h3 class="w3-center">Good Choice!</h3>
</body>
</html>
<?php
session_start();

echo '<h1>'.$_SESSION['username'].' you have successfuly logged out.';
echo "<br><h1><a href=index.php>back to Login Page</a></h1>";

$_SESSION=array();
session_destroy();

?>